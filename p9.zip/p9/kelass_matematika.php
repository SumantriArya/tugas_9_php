<?php
    class Matematika {
        //konstanta clss
        const PHI = 3.14;

        //static member variabel
        public static $counter = 100;

        //static member function
        public static function tambahkan($a,$b) {
            return $a + $b;
        }

        //akses member variabel dari dalam class
        public static function naikanCounter(){
            self::$counter;
        }

        // akses konstata class
        public static function luaslingkaran($jari){
            $luas = self::PHI * $jari * $jari;
            return $luas;
        }
    }
    echo 'NILAI PHI '. Matematika::PHI ;
$luasling = Matematika::luasLingkaran(8);
echo 'Luas Lingkaran Jari2nya 8 = ' . $luasling;
 

?>
